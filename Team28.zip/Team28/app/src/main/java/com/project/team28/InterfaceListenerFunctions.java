package com.project.team28;

public interface InterfaceListenerFunctions {
    void setTime(String time);
}
