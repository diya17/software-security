echo "echo "hi"" >> shfile.sh
echo "echo "bye"" >> shfile.sh
sh shfile.sh
